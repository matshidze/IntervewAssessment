from rest_framework import serializers
from contactApp.models import Contact


class ContactSerializer(serializers.ModelSerializer):

    class Meta:
        Model = Contact
        fields = '__all__'
