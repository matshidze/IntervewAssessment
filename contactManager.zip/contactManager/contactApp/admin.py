from django.contrib import admin
from contactApp.models import Contact


class ContactAdmin(admin.ModelAdmin):
    save_on_top = True
    list_display = ('id', 'holder_first_name', 'holder_last_name', 'mobile_number', )
    list_display_links = ('id', )


admin.site.register(Contact, ContactAdmin)
