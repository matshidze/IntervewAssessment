from rest_framework.permissions import IsAuthenticated
from rest_framework.renderers import JSONRenderer
from rest_framework.views import APIView
from rest_framework.response import Response
from contactApp.serializers import ContactSerializer
from contactApp.models import Contact


class ContactViewSet(APIView):
    serializer_class = ContactSerializer
    permission_classes = (IsAuthenticated, )
    renderer_classes = (JSONRenderer, )

    def get(self, request, *args, **kwargs):
        response = dict()
        data = self.request.query_params
        required_params = {'mobile_number'}
        if set(data.keys()).issubset(required_params) is False:
            response.update({'success': False, 'message': 'required field(s) is missing'})
        else:
            contact_instance = Contact.objects.filter(mobile_number=data.get('mobile_number'))
            if contact_instance.count() > 0:
                contact_instance = contact_instance.last()
                contact_serializer = ContactSerializer(contact_instance)
                response.update({'success': True, 'payload': contact_serializer.data, 'message': 'Contact retrieved successfully'})
        return Response(response)

    def post(self, request, *args, **kwargs):
        response = dict()
        required_params = {'holder_first_name', 'holder_last_name', 'mobile_number', 'notes', 'email_address'}
        if required_params.issubset(self.request.data.keys()) is False:
            response.update({'success': False, 'message': 'Required field(s) is/are missing'})
        else:
            contact_serializer = ContactSerializer(self.request.data)
            if contact_serializer.is_valid() is False:
                response.update({'success': False, 'message': contact_serializer.errors.values()})
            else:
                response.update({'success': True, 'payload': contact_serializer.data, 'message': 'Contact details successfully created'})
        return Response(response)

