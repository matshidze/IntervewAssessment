from django.conf.urls import url, include
from contactApp import viewsets
from rest_framework_simplejwt import views as auth_views

urlpatterns = [
    url(r'auth/access-token/', auth_views.TokenObtainPairView.as_view(), name='token_obtain_pair'),
    url(r'auth/refresh-token/', auth_views.TokenRefreshView.as_view(), name='token_refresh_view'),
    url(r'contact/$', view=viewsets.ContactViewSet.as_view(), name='contact-viewsets')
]
